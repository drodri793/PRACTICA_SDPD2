"""
DAG de Apache Airflow para pipeline ETL de datos de restaurantes TripAdvisor.
Asignatura: SDPD2 - GCID | Curso 2025/2026
Autores: [Nombre del grupo]

Descripción:
    Pipeline ETL que extrae datos de restaurantes europeos de TripAdvisor,
    realiza limpieza y transformación, y publica los resultados en Apache Kafka.

Estructura del DAG:
    extract → clean → transform → load_to_kafka
"""

import ast
import json
import logging
import tomllib
from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import matplotlib
matplotlib.use("Agg")  # Backend sin GUI, necesario en entornos Airflow
import matplotlib.pyplot as plt
from kafka import KafkaProducer

from airflow.decorators import dag, task
from pendulum import datetime

# ---------------------------------------------------------------------------
# Carga de configuración desde fichero TOML
# ---------------------------------------------------------------------------
CONFIG_PATH = Path(__file__).parent / "config.toml"
with open(CONFIG_PATH, "rb") as f:
    CFG = tomllib.load(f)

# Logger de Airflow
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Definición del DAG
# ---------------------------------------------------------------------------
@dag(
    dag_id="tripadvisor_etl_pipeline",
    description="Pipeline ETL para datos de restaurantes TripAdvisor europeos",
    schedule=CFG["airflow"]["schedule"],
    start_date=datetime(2026, 1, 1),
    catchup=False,
    tags=["tripadvisor", "etl", "restaurantes"],
)
def tripadvisor_etl_pipeline():
    """
    DAG principal del pipeline ETL.

    Tareas:
        1. extract      → Lee el CSV y lo guarda como Parquet.
        2. clean        → Limpieza de nulos, duplicados y valores erróneos.
        3. transform    → Transformaciones y generación de gráficas EDA.
        4. load_to_kafka → Publica los datos procesados en Apache Kafka.
    """

    # -----------------------------------------------------------------------
    # TAREA 1: EXTRACT
    # -----------------------------------------------------------------------
    @task()
    def extract() -> str:
        """
        Extrae los datos del fichero CSV de TripAdvisor y los almacena
        en formato Parquet para un procesamiento posterior más eficiente.

        Validaciones realizadas:
            - Comprueba que el fichero CSV de entrada existe.
            - Verifica que las columnas obligatorias están presentes.
            - Registra el número de filas y columnas cargadas.

        Returns:
            str: Ruta al fichero Parquet generado.
        """
        csv_path = Path(CFG["data"]["raw_csv_path"])
        parquet_path = Path(CFG["data"]["parquet_path"])

        # Validar existencia del CSV
        if not csv_path.exists():
            raise FileNotFoundError(f"CSV no encontrado en: {csv_path}")

        log.info("Leyendo CSV desde: %s", csv_path)

        # Leer con pandas usando tipos eficientes
        df = pd.read_csv(
            csv_path,
            dtype={
                "restaurant_link":   "string",
                "restaurant_name":   "string",
                "country":           "string",
                "region":            "string",
                "province":          "string",
                "city":              "string",
                "address":           "string",
                "latitude":          "float32",
                "longitude":         "float32",
                "claimed":           "string",
                "awards":            "string",
                "popularity_detailed": "string",
                "top_tags":          "string",
                "price_level":       "string",
                "price_range":       "string",
                "meals":             "string",
                "cuisines":          "string",
                "special_diets":     "string",
                "features":          "string",
                "vegetarian_friendly": "string",
                "vegan_options":     "string",
                "gluten_free":       "string",
            },
            low_memory=False,
        )

        log.info("Filas cargadas: %d | Columnas: %d", len(df), len(df.columns))

        # Validar columnas obligatorias según esquema conocido
        required_cols = CFG["data"]["required_columns"]
        missing = [c for c in required_cols if c not in df.columns]
        if missing:
            raise ValueError(f"Columnas obligatorias ausentes en el CSV: {missing}")

        log.info("Esquema validado correctamente.")

        # Guardar en Parquet (más eficiente para fases posteriores)
        parquet_path.parent.mkdir(parents=True, exist_ok=True)
        table = pa.Table.from_pandas(df)
        pq.write_table(table, parquet_path, compression="snappy")

        log.info("Parquet guardado en: %s", parquet_path)
        return str(parquet_path)

    # -----------------------------------------------------------------------
    # TAREA 2: CLEAN
    # -----------------------------------------------------------------------
    @task()
    def clean(parquet_path: str) -> str:
        """
        Limpia los datos crudos del Parquet generado en la fase de extracción.

        Operaciones realizadas:
            - Elimina filas completamente duplicadas.
            - Descarta columnas con más del umbral configurado de valores nulos.
            - Imputa nulos en columnas clave con valores por defecto.
            - Normaliza texto (strip, lowercase) en columnas de categoría.
            - Valida y filtra el rango de avg_rating (1.0 a 5.0).
            - Convierte total_reviews_count a entero limpio.

        Args:
            parquet_path (str): Ruta al Parquet de entrada (salida de extract).

        Returns:
            str: Ruta al Parquet limpio generado.
        """
        df = pq.read_table(parquet_path).to_pandas()
        log.info("[CLEAN] Filas iniciales: %d", len(df))

        # 1. Eliminar duplicados exactos
        before = len(df)
        df.drop_duplicates(inplace=True)
        log.info("[CLEAN] Duplicados eliminados: %d", before - len(df))

        # 2. Descartar columnas con exceso de nulos
        null_threshold = CFG["cleaning"]["null_drop_threshold"]
        null_ratio = df.isnull().mean()
        cols_to_drop = null_ratio[null_ratio > null_threshold].index.tolist()
        # Nunca descartar columnas obligatorias
        cols_to_drop = [c for c in cols_to_drop if c not in CFG["data"]["required_columns"]]
        df.drop(columns=cols_to_drop, inplace=True)
        log.info("[CLEAN] Columnas descartadas por exceso de nulos (>%.0f%%): %s",
                 null_threshold * 100, cols_to_drop)

        # 3. Imputar nulos en columnas clave
        if "price_level" in df.columns:
            df["price_level"].fillna("Unknown", inplace=True)
        if "cuisines" in df.columns:
            df["cuisines"].fillna("Unknown", inplace=True)
        if "city" in df.columns:
            df["city"].fillna("Unknown", inplace=True)

        # 4. Normalizar texto en columnas de categoría
        text_cols = ["country", "city", "cuisines", "price_level"]
        for col in text_cols:
            if col in df.columns:
                df[col] = df[col].astype(str).str.strip().str.title()

        # 5. Validar rango de avg_rating (1.0 – 5.0)
        if "avg_rating" in df.columns:
            df["avg_rating"] = pd.to_numeric(df["avg_rating"], errors="coerce")
            before = len(df)
            df = df[df["avg_rating"].between(1.0, 5.0) | df["avg_rating"].isna()]
            log.info("[CLEAN] Filas con avg_rating fuera de rango eliminadas: %d",
                     before - len(df))
            # Imputar nulos restantes con la mediana
            median_rating = df["avg_rating"].median()
            df["avg_rating"].fillna(median_rating, inplace=True)

        # 6. Convertir total_reviews_count a entero
        if "total_reviews_count" in df.columns:
            df["total_reviews_count"] = (
                pd.to_numeric(df["total_reviews_count"], errors="coerce")
                .fillna(0)
                .astype(int)
            )

        log.info("[CLEAN] Filas tras limpieza: %d", len(df))

        # Guardar Parquet limpio
        clean_path = CFG["data"]["clean_parquet_path"]
        Path(clean_path).parent.mkdir(parents=True, exist_ok=True)
        pq.write_table(pa.Table.from_pandas(df), clean_path, compression="snappy")
        log.info("[CLEAN] Parquet limpio guardado en: %s", clean_path)
        return clean_path

    # -----------------------------------------------------------------------
    # TAREA 3: TRANSFORM
    # -----------------------------------------------------------------------
    @task()
    def transform(clean_path: str) -> str:
        """
        Aplica transformaciones sobre los datos limpios y genera gráficas EDA.

        Operaciones realizadas:
            - One-hot encoding de price_level.
            - Extracción y conteo de tags desde la columna top_tags (lista Python).
            - Normalización min-max de total_reviews_count.
            - Generación de gráficas EDA: distribución de ratings y top países.

        Args:
            clean_path (str): Ruta al Parquet limpio (salida de clean).

        Returns:
            str: Ruta al Parquet transformado listo para Kafka.
        """
        df = pq.read_table(clean_path).to_pandas()
        log.info("[TRANSFORM] Filas recibidas: %d", len(df))

        # 1. One-hot encoding de price_level
        if "price_level" in df.columns:
            dummies = pd.get_dummies(df["price_level"], prefix="price").astype(int)
            df = pd.concat([df, dummies], axis=1)
            df.drop(columns=["price_level"], inplace=True)
            log.info("[TRANSFORM] One-hot encoding de price_level aplicado. "
                     "Nuevas columnas: %s", list(dummies.columns))

        # 2. Extraer número de tags desde top_tags (formato lista Python en texto)
        if "top_tags" in df.columns:
            def count_tags(val):
                try:
                    parsed = ast.literal_eval(str(val))
                    return len(parsed) if isinstance(parsed, list) else 0
                except Exception:
                    return 0
            df["num_top_tags"] = df["top_tags"].apply(count_tags)
            df.drop(columns=["top_tags"], inplace=True)
            log.info("[TRANSFORM] Columna num_top_tags creada desde top_tags.")

        # 3. Normalización min-max de total_reviews_count
        if "total_reviews_count" in df.columns:
            min_v = df["total_reviews_count"].min()
            max_v = df["total_reviews_count"].max()
            if max_v > min_v:
                df["reviews_normalized"] = (
                    (df["total_reviews_count"] - min_v) / (max_v - min_v)
                ).astype("float32")
            else:
                df["reviews_normalized"] = 0.0
            log.info("[TRANSFORM] Normalización min-max de total_reviews_count aplicada.")

        # 4. Generación de gráficas EDA
        plots_dir = Path(CFG["data"]["plots_dir"])
        plots_dir.mkdir(parents=True, exist_ok=True)

        # Gráfica 1: Distribución de avg_rating
        if "avg_rating" in df.columns:
            fig, ax = plt.subplots(figsize=(8, 4))
            df["avg_rating"].dropna().hist(bins=20, ax=ax, color="#2196F3", edgecolor="white")
            ax.set_title("Distribución de avg_rating")
            ax.set_xlabel("Rating medio")
            ax.set_ylabel("Número de restaurantes")
            fig.tight_layout()
            fig.savefig(plots_dir / "distribucion_avg_rating.png", dpi=150)
            plt.close(fig)
            log.info("[TRANSFORM] Gráfica de distribución de ratings guardada.")

        # Gráfica 2: Top 10 países por número de restaurantes
        if "country" in df.columns:
            top_countries = df["country"].value_counts().head(10)
            fig, ax = plt.subplots(figsize=(10, 5))
            top_countries.plot(kind="bar", ax=ax, color="#4CAF50", edgecolor="white")
            ax.set_title("Top 10 países por número de restaurantes")
            ax.set_xlabel("País")
            ax.set_ylabel("Número de restaurantes")
            ax.tick_params(axis="x", rotation=45)
            fig.tight_layout()
            fig.savefig(plots_dir / "top10_paises.png", dpi=150)
            plt.close(fig)
            log.info("[TRANSFORM] Gráfica de top países guardada.")

        # Guardar Parquet transformado
        transformed_path = CFG["data"]["transformed_parquet_path"]
        Path(transformed_path).parent.mkdir(parents=True, exist_ok=True)
        pq.write_table(pa.Table.from_pandas(df), transformed_path, compression="snappy")
        log.info("[TRANSFORM] Parquet transformado guardado en: %s", transformed_path)
        return transformed_path

    # -----------------------------------------------------------------------
    # TAREA 4: LOAD TO KAFKA
    # -----------------------------------------------------------------------
    @task()
    def load_to_kafka(transformed_path: str) -> None:
        """
        Publica los registros procesados en un topic de Apache Kafka.

        Cada fila del DataFrame se serializa a JSON y se envía al topic
        configurado en config.toml. Los registros se envían en micro-batches
        para mejorar el rendimiento.

        Args:
            transformed_path (str): Ruta al Parquet transformado (salida de transform).
        """
        df = pq.read_table(transformed_path).to_pandas()
        log.info("[KAFKA] Registros a publicar: %d", len(df))

        kafka_cfg = CFG["kafka"]

        # Inicializar productor Kafka
        producer = KafkaProducer(
            bootstrap_servers=kafka_cfg["bootstrap_servers"],
            value_serializer=lambda v: json.dumps(v, ensure_ascii=False).encode("utf-8"),
            batch_size=kafka_cfg["batch_size"],
            linger_ms=kafka_cfg["linger_ms"],
            acks=kafka_cfg["acks"],
        )

        topic = kafka_cfg["topic"]
        batch_size = kafka_cfg["batch_size"]
        sent = 0

        # Enviar en micro-batches
        for i in range(0, len(df), batch_size):
            batch = df.iloc[i : i + batch_size]
            for _, row in batch.iterrows():
                record = row.where(pd.notna(row), None).to_dict()
                producer.send(topic, value=record)
            producer.flush()
            sent += len(batch)
            log.info("[KAFKA] Enviados %d / %d registros", sent, len(df))

        producer.close()
        log.info("[KAFKA] Todos los registros publicados en el topic '%s'.", topic)

    # -----------------------------------------------------------------------
    # Definición de la secuencia de ejecución del DAG
    # -----------------------------------------------------------------------
    raw_parquet   = extract()
    clean_parquet = clean(raw_parquet)
    trans_parquet = transform(clean_parquet)
    load_to_kafka(trans_parquet)


# Instanciar el DAG
tripadvisor_etl_pipeline()
