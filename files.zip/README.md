# Pipeline ETL — TripAdvisor European Restaurants
**SDPD2 - GCID | Curso 2025/2026**

Pipeline de datos con Apache Airflow para limpieza, transformación y publicación en Kafka del dataset de restaurantes europeos de TripAdvisor.

---

## Estructura del proyecto

```
.
├── tripadvisor_dag.py      # DAG principal de Airflow
├── config.toml             # Fichero de configuración centralizado
├── requirements.txt        # Dependencias Python
└── data/
    ├── raw/                # CSV original de Kaggle (ponlo aquí)
    ├── interim/            # Parquets intermedios (generados automáticamente)
    ├── processed/          # Parquet final transformado
    └── plots/              # Gráficas EDA generadas
```

---

## Requisitos previos

- Python 3.11+
- Apache Airflow 2.8+
- Apache Kafka corriendo en `localhost:9092`

---

## Instalación

```bash
# 1. Crear entorno virtual
python -m venv .venv
source .venv/bin/activate  # En Windows: .venv\Scripts\activate

# 2. Instalar dependencias
pip install -r requirements.txt

# 3. Inicializar Airflow (solo la primera vez)
export AIRFLOW_HOME=$(pwd)/airflow_home
airflow db init
airflow users create \
    --username admin --password admin \
    --firstname Admin --lastname User \
    --role Admin --email admin@example.com
```

---

## Configuración

Edita `config.toml` antes de ejecutar. Lo más importante:

| Clave | Descripción |
|---|---|
| `data.raw_csv_path` | Ruta al CSV descargado de Kaggle |
| `kafka.bootstrap_servers` | Dirección de tu broker Kafka |
| `kafka.topic` | Nombre del topic de destino |
| `cleaning.null_drop_threshold` | % de nulos para descartar columna (0.80 = 80%) |

---

## Ejecución

```bash
# 1. Copiar el DAG a la carpeta de Airflow
cp tripadvisor_dag.py $AIRFLOW_HOME/dags/
cp config.toml $AIRFLOW_HOME/dags/

# 2. Arrancar Airflow
airflow webserver --port 8080 &
airflow scheduler &

# 3. Abrir la interfaz web
# http://localhost:8080  (usuario: admin, contraseña: admin)

# 4. Activar el DAG "tripadvisor_etl_pipeline" y ejecutarlo manualmente
#    desde la interfaz web, o con:
airflow dags trigger tripadvisor_etl_pipeline
```

---

## Estructura del DAG

```
extract → clean → transform → load_to_kafka
```

| Tarea | Patrón ETL | Descripción |
|---|---|---|
| `extract` | **Extract** | Lee el CSV con tipos eficientes, valida el esquema de columnas y guarda en Parquet (Snappy) |
| `clean` | **Extract** | Elimina duplicados, descarta columnas con >80% nulos, imputa valores, normaliza texto y valida rangos de `avg_rating` |
| `transform` | **Transform** | One-hot encoding de `price_level`, extracción de `top_tags`, normalización min-max de reviews y generación de gráficas EDA |
| `load_to_kafka` | **Load** | Serializa cada fila a JSON y la publica en el topic Kafka configurado, en micro-batches de 500 registros |

---

## Kafka — arrancar un broker local rápido (Docker)

Si no tienes Kafka instalado, puedes levantarlo con Docker:

```bash
docker run -d --name kafka \
  -p 9092:9092 \
  -e KAFKA_CFG_NODE_ID=0 \
  -e KAFKA_CFG_PROCESS_ROLES=controller,broker \
  -e KAFKA_CFG_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093 \
  -e KAFKA_CFG_LISTENER_SECURITY_PROTOCOL_MAP=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT \
  -e KAFKA_CFG_CONTROLLER_QUORUM_VOTERS=0@localhost:9093 \
  -e KAFKA_CFG_CONTROLLER_LISTENER_NAMES=CONTROLLER \
  bitnami/kafka:latest
```

Crear el topic:
```bash
docker exec kafka kafka-topics.sh \
  --create --topic tripadvisor-restaurants \
  --bootstrap-server localhost:9092 \
  --partitions 1 --replication-factor 1
```
